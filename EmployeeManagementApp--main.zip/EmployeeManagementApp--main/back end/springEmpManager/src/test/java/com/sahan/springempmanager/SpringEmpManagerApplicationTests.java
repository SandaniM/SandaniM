package com.sahan.springempmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmpManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
