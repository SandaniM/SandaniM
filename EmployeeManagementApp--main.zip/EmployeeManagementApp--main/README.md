# Employee Management App

front-end :- Angular <br>
backend :- spring boot <br> 
database :- mySql<br>

## Run

front-end :- cd the root file and run npm install <br>v
back-end :- edit the application.properties file and configure the listening port <br>


### Team Members

KUDSE202F - 006 | sahan <br>
KUDSE202F - 012 | danoja <br>
KUDSE202F - 029 | mihiranga <br>
KUDSE202F - 030 | nusky <br>
KUDSE202F - 011 | shem <br>
KUDSE202F - 013 | tharani <br>
